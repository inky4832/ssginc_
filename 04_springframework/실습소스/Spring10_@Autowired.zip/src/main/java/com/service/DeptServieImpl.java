package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.dao.DeptDAO;

public class DeptServieImpl {
	
	@Autowired(required = false)
	DeptDAO dao;


	public String getMesg() {
		return dao.getMesg();
	}

}
