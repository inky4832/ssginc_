package com.dao;

public class DeptDAO {

	
	public DeptDAO() {
		System.out.println("DeptDAO 생성자");
	}

	public String getMesg() {
		return "Hello World";
	}
}
