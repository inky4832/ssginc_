package com.service;

import java.util.Set;

import com.dto.Cat;

public class UserService {

	//1:n
	Set<Cat> set;
	
	public Set<Cat> getSet() {
		return set;
	}
	// DI
	public void setSet(Set<Cat> set) {
		this.set = set;
	}

	// 추가 메서드
	public String getMesg() {
		return "hello world";
	}
	
}
