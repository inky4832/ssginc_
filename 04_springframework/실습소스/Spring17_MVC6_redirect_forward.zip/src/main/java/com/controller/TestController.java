package com.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class TestController {

	
	//forward
	@GetMapping("/forward")
	public String forward(Model m) {
		System.out.println("TestController.forward");
		
		m.addAttribute("userid", "홍길동");
		
//			return "main";  // /WEB-INF/views/main.jsp
		return "forward:main";
	}
	
	
	
	//redirect
	@GetMapping("/redirect")
	public String redirect(Model m) {
		System.out.println("TestController.redirect");
		
		m.addAttribute("userid", "홍길동");
		
//		return "main";  // /WEB-INF/views/main.jsp
		return "redirect:main";
	}
	
	@GetMapping("/main")
	public String home() {
		System.out.println("TestController.home");
		return "home";
	}

}
