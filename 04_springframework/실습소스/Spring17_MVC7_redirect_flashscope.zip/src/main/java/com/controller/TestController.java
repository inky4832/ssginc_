package com.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class TestController {

	
	//redirect
	@GetMapping("/redirect")
	public String redirect(Model m) {
		System.out.println("TestController.redirect");
		m.addAttribute("userid", "홍길동");
//		return "main";  // /WEB-INF/views/main.jsp
		return "redirect:main";
	}
	
	//redirect-flash scope
	//flash
	@GetMapping("/flash")
	public String flash(RedirectAttributes m) {
		System.out.println("TestController.flash");
		m.addFlashAttribute("userid", "홍길동");
//		return "main";  // /WEB-INF/views/main.jsp
		return "redirect:main";
	}
	
	
	
	
	@GetMapping("/main")
	public String home() {
		System.out.println("TestController.home");
		return "home";
	}

}


// A 이외의 서블릿

  HttpSession session = request.getSession();
  Xxx data = (XXX)session.getAttribute("x");
  //A를 거쳣는지 여부 확인
  if(data!=null) {
	  //작업
  }else {
	  //A로 요청
	  response.sendRedirect("A");
  }









