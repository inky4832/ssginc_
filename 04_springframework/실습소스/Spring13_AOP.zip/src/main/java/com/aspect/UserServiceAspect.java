package com.aspect;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

// UserService에 부가기능 추가하는 빈

@Aspect
public class UserServiceAspect {

	@Pointcut("execution(public String sayHello())")
	public void xxx() {}
	
	@Pointcut("execution(public String callHello())")
	public void xxx2() {}
	
	@Before("xxx()")
	public void method() {
		System.out.println("UserServiceAspect.before advice");
	}
}
