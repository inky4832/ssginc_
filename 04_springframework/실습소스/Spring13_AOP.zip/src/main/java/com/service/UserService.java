package com.service;


// target
public class UserService {

	// 핵심 기능 메서드
	public String sayHello() {
		return "hello";
	}
	
	
}
