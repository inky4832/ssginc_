package com.service;

import com.dao.DeptDAO;

public class DeptServieImpl {
	
	DeptDAO dao;
	String name;
	public DeptServieImpl(DeptDAO x) {
		System.out.println("DeptServieImpl 생성자");
		dao = x;
	}
	//다음 생성으로 호출
	public DeptServieImpl(String name, DeptDAO x) {
		System.out.println("DeptServieImpl 생성자");
		dao = x;
		this.name = name;
	}
	public String getMesg() {
		return dao.getMesg()+"\t"+name;
	}

}
