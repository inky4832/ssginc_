package com.dao;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

//@Component
@Repository
public class UserDAO {
	

	public String getMesg() {
		return "UserDAO.hello";
	}
}
