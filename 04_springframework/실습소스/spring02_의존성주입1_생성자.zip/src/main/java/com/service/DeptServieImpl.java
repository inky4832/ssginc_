package com.service;

import com.dao.DeptDAO;

public class DeptServieImpl {
	DeptDAO dao;
	public DeptServieImpl(DeptDAO x) {
		System.out.println("DeptServieImpl 생성자");
		dao = x;
	}
	
	//고전 방식:기능처리
	public String getMesg() {
		return dao.getMesg();
	}

}
