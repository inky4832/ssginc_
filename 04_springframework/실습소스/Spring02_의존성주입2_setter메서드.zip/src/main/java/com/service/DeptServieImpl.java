package com.service;

import com.dao.DeptDAO;

public class DeptServieImpl {
	
	DeptDAO dao;

	public DeptServieImpl() {
		System.out.println("DeptServieImpl 생성자");
	}
	
    // setter 메서드 이용한 주입
	public void setDao(DeptDAO dao) {
		this.dao = dao;
	}

	
	public DeptDAO getDao() {
		return dao;
	}






	public String getMesg() {
		return dao.getMesg();
	}

}
