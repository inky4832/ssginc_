package com.service;

public class UserServiceDev implements UserService{

	@Override
	public String getService() {
		return "UserServiceDev";
	}

}
