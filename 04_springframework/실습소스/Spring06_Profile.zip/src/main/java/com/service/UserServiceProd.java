package com.service;

public class UserServiceProd implements UserService{

	@Override
	public String getService() {
		return "UserServiceProd";
	}

}
