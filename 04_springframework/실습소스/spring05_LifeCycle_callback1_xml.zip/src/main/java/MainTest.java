import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import com.service.DeptServieImpl;

public class MainTest {

	public static void main(String[] args) {
		
		// 1. 고전  방식
		DeptServieImpl service = new DeptServieImpl();
		String mesg = service.getMesg();
		System.out.println("고전방식:" + mesg);

		// 2. Spring 방식
		/*
		   -스프링에서는 생성된 클래스를 빈(bean)이라고 부른다.
		   
		   -빈생성 순서
		   가. 빈 작성 ( *.java)
		   나. 빈을 xml에 등록 (src/main/resource, 패키지 사용 가능 )
		    예> com/config/user.xml
			
		   다. ApplicationContext 생성
		    - xml에 등록된 빈들의 lifecycle관리( 생성~소멸)
		    - 빈생성은 기본적으로 기본생성자로 생성한다.
		  라. 빈얻기
		     문법: 클래스 변수명 = ctx.getBean("id값", 클래스.class);
		   
		*/
		
		GenericXmlApplicationContext ctx = 
				new GenericXmlApplicationContext("com/config/user.xml");
		
		//빈얻기
		DeptServieImpl service2 = ctx.getBean("xxx", DeptServieImpl.class);
		String mesg2 = service2.getMesg();
		System.out.println("Spring 방식:" + mesg2);
		
		ctx.close();
	}

}
