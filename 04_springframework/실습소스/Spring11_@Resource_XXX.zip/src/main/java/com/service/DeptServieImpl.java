package com.service;

import javax.annotation.Resource;

import com.dao.DeptDAO;


public class DeptServieImpl {
	
	@Resource
	DeptDAO dao;


	public String getMesg() {
		return dao.getMesg();
	}

}
