package com.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class TestController {

	@GetMapping("/main")
	public String home() {
		System.out.println("TestController.home");
		return "home";
	}
	
	
}
