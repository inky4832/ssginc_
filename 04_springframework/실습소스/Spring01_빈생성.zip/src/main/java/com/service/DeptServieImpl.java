package com.service;

public class DeptServieImpl {

	public DeptServieImpl() {
		System.out.println("DeptServieImpl 생성자");
	}
	
	//기능처리
	public String getMesg() {
		return "Hello World";
	}

}
