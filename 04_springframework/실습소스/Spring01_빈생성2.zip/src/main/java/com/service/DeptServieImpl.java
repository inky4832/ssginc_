package com.service;

public class DeptServieImpl {

	public DeptServieImpl(int n, String name) {
		System.out.println("DeptServieImpl 생성자"+n+"\t"+name);
	}

	public DeptServieImpl(int n) {
		System.out.println("DeptServieImpl 생성자"+n);
	}
	
	//기능처리
	public String getMesg() {
		return "Hello World";
	}

}
