import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import com.service.DeptServieImpl;

public class MainTest {

	public static void main(String[] args) {
		
	
		
		ApplicationContext ctx = 
				new GenericXmlApplicationContext("com/config/user.xml");
		
		//빈얻기
		DeptServieImpl service = ctx.getBean("xxx", DeptServieImpl.class);
		String mesg = service.getMesg();
		System.out.println("첫번째 bean:" + mesg);
		
		DeptServieImpl service2 = ctx.getBean("xxx", DeptServieImpl.class);
		String mesg2 = service2.getMesg();
		System.out.println("두번째 bean:" + mesg2);
		
		System.out.println(service == service2);
	}

}
