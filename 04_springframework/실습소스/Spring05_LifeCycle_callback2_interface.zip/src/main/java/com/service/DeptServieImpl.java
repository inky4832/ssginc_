package com.service;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class DeptServieImpl 
 implements InitializingBean, DisposableBean{

	public DeptServieImpl() {
		System.out.println("DeptServieImpl 생성자");
	}
	
	//기능처리
	public String getMesg() {
		return "Hello World";
	}


	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("xxx 초기화");
	}

	@Override
	public void destroy() throws Exception {
		System.out.println("destroy 자원반납");		
	}
}
