

import Profile from './components/Profile.js';
import logo from './logo.svg';
function App() {

   
 
  return (
    <div>
       <Profile />
      </div>
  );
}

export default App;
