import Profile from "./components/Profile";


function App() {


 console.log("App");
  return (
      <div>
         <Profile />
      </div>
  );
}

export default App;
