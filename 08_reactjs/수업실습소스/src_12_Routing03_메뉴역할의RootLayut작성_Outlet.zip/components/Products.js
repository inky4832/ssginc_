
export default function Products() {
  return (
    <div>
       <h2>Products 화면</h2>
    </div>
  );
}


