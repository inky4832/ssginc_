
import {useState} from 'react';
import Greeting from './Greeting';

function Profile(){
   

    return (
      <>
       <Greeting />
      </>
    )
  }

export default  Profile;
