

function Profile({xxx}){

  console.log("Profile");
    return (
      <>
         Profile값:{xxx}
     </>
    )
  }

export default  Profile;
