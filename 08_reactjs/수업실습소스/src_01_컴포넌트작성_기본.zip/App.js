
// 임의의 컴포넌트 작성
function Profile(){
  return (
    <p>Profile</p>
  )
}



function App() {
  return (
    <div>
       <Profile />
    </div>
  );
}

export default App;
