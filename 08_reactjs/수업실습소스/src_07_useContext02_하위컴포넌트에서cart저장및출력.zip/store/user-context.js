// user-context.js
// 모든 컴포넌트에서 사용
import { createContext } from "react";
export const UserContext = createContext('');
