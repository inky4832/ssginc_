

// 임의의 컴포넌트 외부 파일로 작성
function Profile(){
    return (
      <p>Profile</p>
    )
  }

export default  Profile;
