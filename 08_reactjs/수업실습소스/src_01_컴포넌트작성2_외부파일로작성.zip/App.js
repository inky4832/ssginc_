

import Profile from './components/Profile.js';

function App() {
  return (
    <div>
       <Profile />
    </div>
  );
}

export default App;
