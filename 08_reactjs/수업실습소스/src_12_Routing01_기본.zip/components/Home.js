
function Home() {
  return (
    <div>
       <h2>Home 화면</h2>
    </div>
  );
}

export default Home;
