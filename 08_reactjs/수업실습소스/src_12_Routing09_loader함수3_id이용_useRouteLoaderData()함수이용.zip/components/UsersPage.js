

import UserList from "./UserList";

function UsersPage() {

  console.log("UsersPage 생성");
  return (
    <>
      <UserList />
    </>
  );
}

export default UsersPage;
