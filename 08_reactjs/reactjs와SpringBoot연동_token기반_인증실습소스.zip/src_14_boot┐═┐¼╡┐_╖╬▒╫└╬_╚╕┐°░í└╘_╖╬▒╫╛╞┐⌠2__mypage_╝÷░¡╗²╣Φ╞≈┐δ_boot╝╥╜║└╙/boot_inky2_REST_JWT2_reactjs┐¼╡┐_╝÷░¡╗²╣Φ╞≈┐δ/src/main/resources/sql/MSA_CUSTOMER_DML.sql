
INSERT INTO MSA_CUSTOMER( EMAIL, PWD, NAME )
VALUES('hong@korea.com', '1234', '홍길동' ); 

INSERT INTO MSA_CUSTOMER( EMAIL, PWD, NAME )
VALUES('park@korea.com', '1234', '박문각' ); 


INSERT INTO MSA_CUSTOMER( EMAIL, PWD, NAME )
VALUES('lee@korea.com', '1234', '이순신' ); 