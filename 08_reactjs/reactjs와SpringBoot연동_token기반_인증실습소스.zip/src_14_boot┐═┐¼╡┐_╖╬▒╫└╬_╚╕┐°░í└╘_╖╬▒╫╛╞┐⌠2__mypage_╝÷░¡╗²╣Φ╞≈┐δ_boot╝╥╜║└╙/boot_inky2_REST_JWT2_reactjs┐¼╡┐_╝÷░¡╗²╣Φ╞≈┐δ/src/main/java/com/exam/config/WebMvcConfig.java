package com.exam.config;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.exam.interceptor.JwtInterceptor;



@Component
public class WebMvcConfig implements WebMvcConfigurer {

	@Autowired
	JwtInterceptor jwtInterceptor;
	
	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(jwtInterceptor)
		        .addPathPatterns("/api/**") // 기본 적용 경로
		        .excludePathPatterns(Arrays.asList("/api/user/**"));// 적용 제외 경로
	}
	
	@Override
	public void addCorsMappings(CorsRegistry registry) {
		
		registry.addMapping("/**")
				.allowedOriginPatterns("*")
				.allowedHeaders("*")
				.allowCredentials(false)
				.allowedMethods("*");
	}
}
