package com.exam.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.exam.dto.Customer;
import com.exam.jwt.JwtUtil;


public interface CustomerService {

	public Customer insertCustomer(Customer customer) throws Exception;
	public Customer login(Customer customer) throws Exception;
    public Customer deleteCustomer(String email) throws Exception;
	
	public Customer selectCustomerByEmail(String email) throws Exception;

}
