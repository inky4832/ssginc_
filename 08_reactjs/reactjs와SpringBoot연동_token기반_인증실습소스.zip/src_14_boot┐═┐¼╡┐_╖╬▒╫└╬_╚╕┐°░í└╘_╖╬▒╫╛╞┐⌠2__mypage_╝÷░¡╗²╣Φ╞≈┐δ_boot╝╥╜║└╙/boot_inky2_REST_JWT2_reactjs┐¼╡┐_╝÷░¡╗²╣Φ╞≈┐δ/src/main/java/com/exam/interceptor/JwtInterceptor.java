package com.exam.interceptor;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import com.exam.jwt.JwtUtil;

@Component
public class JwtInterceptor implements HandlerInterceptor {

	@Autowired
	JwtUtil jwtUtil;

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		System.out.println(">>>>>>>>>>>>>>>>JwtInterceptor.preHandle");
		
		//preflight 허용목적
		if(request.getMethod().equals("OPTIONS")) {
			return true;
		}
		// request의 헤더에서 jwtAuthToken 으로 넘어온 정보 조회
		String authToken = request.getHeader("jwtAuthToken");
		System.out.printf("경로:{}, 토큰:{} ", request.getServletPath(), authToken);
		
		// 유효한 토큰이면 진행, 아니면 예외 발생
		if(authToken != null ) {
		  Map<String, Object> map = jwtUtil.checkAndGetClaims(authToken);
		  System.out.println("유효한 토큰임:" + map);
		 return true;
		}else {
			throw new Exception("요청하신 토큰이 유효하지 않습니다.");
		}
		
	}
	
	
}
