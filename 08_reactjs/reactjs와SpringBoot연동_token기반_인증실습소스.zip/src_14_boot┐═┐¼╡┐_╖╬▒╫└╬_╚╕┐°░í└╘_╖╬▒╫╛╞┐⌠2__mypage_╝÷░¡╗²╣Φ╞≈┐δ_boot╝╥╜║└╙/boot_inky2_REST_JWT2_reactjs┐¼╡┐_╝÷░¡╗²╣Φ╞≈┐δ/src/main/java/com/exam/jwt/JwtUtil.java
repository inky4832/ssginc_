package com.exam.jwt;

import java.time.Duration;
import java.time.Instant;
import java.util.Date;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

/*
   JwtUtil 기능
    - application.properties에 선언된 속성들을 사용하여 크게
      토큰을 만드는 부분과 토큰의 검증 및 내용 확인 부분으로 구성된다.

*/

@Component
public class JwtUtil {

	@Value("${jwt.salt}")
	String salt;
	
	@Value("${jwt.expmin}")
	Long expireMin;
	
	// 토큰 생성
	public String createAuthToken(String email) {
		return create(email, "authToken", expireMin);
	}
	
	/*
	   로그인 성공시 사용자 정보를 기반으로 JWTToken을 생성해서 반환한다
	   JWTToken = header  + payload + signature
	
	*/
	public String create(String email, String subject, long expireMin) {
	
		final JwtBuilder builder = Jwts.builder();
		// header 설정
		builder.setHeaderParam("type", "JWT"); //토큰의 타입으로 고정값
		// payload 설정 ( claim 정보 포함 )
		
		/////////////////////////////////
		/*
		   만료기간을 시간으로 설정하면 다음 코드 활용한다.
		Instant now = Instant.now();
		Instant expireTime = now.plus(Duration.ofHours(8));
		Date expireDate = Date.from(expireTime);
		*/
		/////////////////////////////////
		Instant now = Instant.now();
//		Instant expireTime = now.plus(Duration.ofMinutes(expireMin));
		Instant expireTime = now.plus(Duration.ofSeconds(40));
		Date expireDate = Date.from(expireTime);
		
		builder.setSubject(subject) //토큰 제목 설정
		       .setExpiration(expireDate); // 유효기간, 실습에서는 40초로 설정
		
		//담고 싶은 정보 설정
		if(email != null) {
			builder.claim("user", email);
		}
		
		// signature - secret key를 이용한 암호화
		builder.signWith(SignatureAlgorithm.HS256, salt.getBytes());
		
		// 마지막 직렬화 처리
		final String jwt = builder.compact();
		System.out.println("토큰발행: " + jwt);
		return jwt;
	}
	
	/*
	    jwt 토큰을 분석해서 필요한 정보를 반환한다.
	    토큰에 문제가 있으면 RuntimeException을 발생시킨다.
	*/
	public Map<String, Object> checkAndGetClaims(String jwt){
		
		Jws<Claims> claims = Jwts.parser().setSigningKey(salt.getBytes()).parseClaimsJws(jwt);
		System.out.println("claims: " + claims);
		
		// Claims는 Map의 구현체
		return claims.getBody();
	}
	
}
