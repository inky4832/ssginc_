import { Link, Form , redirect, json, useLoaderData} from 'react-router-dom';
import { getAuthToken } from '../util/auth';
function MyPagePage(){
  const user = useLoaderData();
  console.log("MyPagePage,user>>>>>>>>>>>>.",user)
    return (
        <>
         <h1>회원 MyPage</h1>
         <table border="1">
           <thead> 
                <tr>
                    <th>email</th>
                    <th>pwd</th>
                    <th>name</th>
                </tr>
            </thead>
            <tbody> 
                <tr >
                    <td>{user.email}</td>
                    <td>{user.pwd}</td>
                    <td>{user.name}</td>
                </tr>    
            </tbody>
          </table>
        </>
    )
 
}
export default MyPagePage;

export async function loader({ request }) {
    console.log("MyPagePage,loader>>>>>>>>>>>>.",request)
    const token = getAuthToken();
    const email = localStorage.getItem("email");
    console.log("token:", token);
    console.log("email:" , email);
    const authData = {
      email: email
    }
    const response = await fetch("http://localhost:8090/api/mypage/", {
        method: "POST",
        headers: {
          'Content-Type': 'application/json',
          'jwtAuthToken': token
        },
        body: JSON.stringify(authData),
      });
     

      if (!response.ok) {
        throw json({ message: 'Could not save event.' }, { status: 500 });
      }
      
    const resData = await response.json();
    console.log("resData", resData);
    return resData;
  }
  