import React from 'react';


export default function Person({ row, idx }){

    return (
        <tr key={idx}>
            <td>{idx + 1}</td>
            <td>{row.name}</td>
            <td>{row.age}</td>
        </tr>
    );
}
