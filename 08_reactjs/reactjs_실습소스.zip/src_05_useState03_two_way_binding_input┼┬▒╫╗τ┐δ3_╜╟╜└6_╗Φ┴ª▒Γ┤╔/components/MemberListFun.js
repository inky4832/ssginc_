import  { useState } from 'react';
import MemberFun from './MemberFun';

function MemberListFun(props) {

    const [inputs, setInputs] = useState({
        memberData: [],
        username: '',
        age: '',
        address: ''
    });


    const { memberData, username, age, address } = inputs;

    const handleChange = (e) => {
        const { value, name } = e.target;
        setInputs({
            ...inputs,
            [name]: value  //이러한 작업을, "불변성을 지킨다" 라고 한다.
            // 불변성을 지켜주어야만 리액트 컴포넌트에서 상태가 업데이트가 되었음을
            // 알수 있고 이에 따라 리랜더링이 진행된다.
            //만약에 inputs[name]=value 이런식으로 기존 상태를 직접 수정하게 되면
            //값을 바꿔도 리랜더링이 되지 않는다.
            //추가로 리엑트에서는 불변성을 지켜주어야만 컴포넌트 업데이스 성능 최적화를
            //제대로 할 수 있다.
        })
    };
    const handleSubmit = (e) => {
        e.preventDefault();
        var user = {
            username,
            age,
            address
        }
        setInputs({
            ...inputs,
            memberData: [...memberData, user]
        })
    };

    const handleDelete = (idx) => {
        setInputs({
            ...inputs,
            memberData: memberData.filter((v, i) => i !== idx)
        })
    };

    return (
        <div>
            <form onSubmit={handleSubmit}>
                이름<input type="text" name="username" value={username}
                    onChange={handleChange} /><br />
        나이<input type="text" name="age" value={age}
                    onChange={handleChange} /><br />
        주소<input type="text" name="address" value={address}
                    onChange={handleChange} /><br />
                <input type="submit" value="저장" />
            </form>
            { memberData.map((row, idx) => {
                return <MemberFun key={idx} idx={idx} row={row} onDelete={handleDelete} />
            })
            }
        </div>
    );
}

export default MemberListFun;