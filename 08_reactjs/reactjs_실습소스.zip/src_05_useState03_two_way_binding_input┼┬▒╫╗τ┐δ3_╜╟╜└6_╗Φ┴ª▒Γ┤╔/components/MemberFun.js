
function MemberFun({ row, idx, onDelete }) {
    return (
        <div>
            {row.username}&nbsp;{row.age}&nbsp;{row.address}<button onClick={() => onDelete(idx)}>삭제</button>
        </div >
    );
}

export default MemberFun;

