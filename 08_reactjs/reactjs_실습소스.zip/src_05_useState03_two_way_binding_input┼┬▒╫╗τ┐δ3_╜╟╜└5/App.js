import  { useState } from 'react';

function App() {

  const [num, setNum] = useState(0);

  const [step, setStep] = useState(1);

  const stepChange = (step)=>{
      setStep(step)
  }
  const increment = (step)=> {
      setNum(num+step)
  }
  const decrement = (step)=> {
      setNum(num - step >= 0 ? num - step : 0)
  }

  console.log("App 호출");
  return (
    <>
        <h2>state 실습</h2>
        step:
        <select onChange={(e) => stepChange(Number.parseInt(e.target.value))}>
            <option>1</option>
            <option>2</option>
            <option>3</option>
        </select><br />
        num:{num}<br />
        <button onClick={() => decrement(step)}>-</button>
        <button onClick={() => increment(step)}>+</button>
  
    </>
  );
}

export default App;
