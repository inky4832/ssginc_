
import MemberListFun from "./components/MemberListFun";

function App() {
  return (
    <>
      <MemberListFun />
    </>
  );
}

export default App;
