
function MemberFun({ row }) {
    return (
        <div>
            {row.username}&nbsp;{row.age}&nbsp;{row.address}
        </div >
    );
}

export default MemberFun;