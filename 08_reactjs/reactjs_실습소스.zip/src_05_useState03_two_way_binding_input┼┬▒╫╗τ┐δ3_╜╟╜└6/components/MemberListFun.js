import { useState } from 'react';
import MemberFun from './MemberFun';

function MemberListFun(props) {

    const [memberData, setMemberData] = useState([])

    const [inputs, setInputs] = useState({
        username: '',
        age: '',
        address: ''
    });

    const { username, age, address } = inputs;

    const handleChange = (e) => {
        const { value, name } = e.target;
        setInputs({
            ...inputs,
            [name]: value
        })
    };
    const handleSubmit = (e) => {
        e.preventDefault();
        var user = {
            username,
            age,
            address
        }
        setMemberData([...memberData, user]);

        console.log(memberData);
    };

    return (
        <div>
            <form onSubmit={handleSubmit}>
                이름<input type="text" name="username" value={username}
                    onChange={handleChange} /><br />
        나이<input type="text" name="age" value={age}
                    onChange={handleChange} /><br />
        주소<input type="text" name="address" value={address}
                    onChange={handleChange} /><br />
                <input type="submit" value="저장" />
            </form>
            <hr/>
            { memberData.map((row, idx) => {
                return <MemberFun key={idx} idx={idx} row={row} />
            })
            }
        </div>
    );
}

export default MemberListFun;