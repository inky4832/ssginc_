import React, { useState } from 'react';
import './GameBoarder.css';

const initialGameBoard =[
    [null, null, null],
    [null, null, null],
    [null, null, null]
];

export default function GameBoarder(props) {

    const [gameBoard, setGameBoard] = useState(initialGameBoard);

    function handleSelect(rowIndex, colIndex){
        //방법1 (배열에 변경사항이 저장되나 동일한 주소값이기 때문에 새롭게 랜더링 안됨.)
        // setGameBoard((prevGameBoard)=>{
        //     prevGameBoard[rowIndex][colIndex]='X';
        //     console.log(">...........", prevGameBoard)
        //     return prevGameBoard;
        // });

        // 방법2 ( 다른 주소값으로 설정했기 때문에 변경되었음을 인식하고 새롭게 랜더링 됨.)
        var newGameBoard= [...gameBoard,]
        newGameBoard[rowIndex][colIndex]='X';
        setGameBoard(newGameBoard);
    }

    console.log("App 호출");
    
    return (
        <ol id="game-board">
            {initialGameBoard.map((row, rowIndex)=><li key={rowIndex}>
                <ol>
                  {
                    row.map((col, colIndex)=>
                    <li key={colIndex}>
                        <button disabled={col !== null}  onClick={()=>handleSelect(rowIndex, colIndex)}>{col}</button>
                    </li>)
                  }
                </ol>
            </li>)}
        </ol>
    );
}

