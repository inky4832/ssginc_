import logo from './logo.svg';
import './App.css';
import GameBoarder from './components/GameBoarder';

function App() {
  return (
    <div>
      <GameBoarder />
    </div>
  );
}

export default App;
