
export default function Contact() {
    return (
            <>
                <ul>
                   <li>홍길동</li>
                   <li>이순신</li>
                   <li>유관순</li>
                   <li>강감찬</li>
                </ul>
           </>
    );
}

