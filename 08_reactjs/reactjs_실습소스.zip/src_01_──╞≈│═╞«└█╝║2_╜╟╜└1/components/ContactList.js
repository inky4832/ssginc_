
import Contact from './Contact';

export default function ContactList() {
    return (
        <div>
            <h2>Contacts 홈페이지</h2>
            <Contact></Contact>
        </div>
    );
}
