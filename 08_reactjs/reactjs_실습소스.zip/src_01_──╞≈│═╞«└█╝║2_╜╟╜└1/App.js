
import ContactList from './components/ContactList';

function App() {
  return (
    <div>
      <ContactList></ContactList>
    </div>
  );
}

export default App;
