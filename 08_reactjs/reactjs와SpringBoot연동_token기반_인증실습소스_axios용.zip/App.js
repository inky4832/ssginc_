
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import HomePage from "./pages/Home";
import ProductsPage ,{ action as productAction } from "./pages/Products";
import RootLayout from "./pages/Root";
import ErrorPage from './pages/Error';
import AuthenticationPage ,{action as authAction} from "./pages/Authentication.js";
import { tokenLoader } from './util/auth';
import { action as logoutAction } from './pages/Logout.js';
import  MyPagePage,{ loader as mypageLoader} from './pages/MyPage.js';

const router = createBrowserRouter([
  {
    path:"/",
    element:<RootLayout/>,
    errorElement: <ErrorPage />,
    id:'tokenRoot',
    loader:tokenLoader,
    children:[
      {index: true, element:<HomePage />},
      {path:'products', element:<ProductsPage />,
       action: productAction},
      
      {path:'auth', 
       element:<AuthenticationPage />,
       action: authAction},
       {path: 'logout',
        action: logoutAction,
       },
       {path:'mypage', element:<MyPagePage />,
        loader: mypageLoader
       },
    ]
  }
]);

function App() {
  return <RouterProvider router={router} />
}

export default App;
