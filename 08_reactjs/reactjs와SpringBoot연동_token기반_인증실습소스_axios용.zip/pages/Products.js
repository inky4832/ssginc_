import { json, redirect } from 'react-router-dom';

function ProductsPage() {
    return <h1>The Products Page</h1>;
  }
  
  export default ProductsPage;
  
  export  function action({ request }) {
    console.log("ProductsPage.action");
    return redirect('/');
  }