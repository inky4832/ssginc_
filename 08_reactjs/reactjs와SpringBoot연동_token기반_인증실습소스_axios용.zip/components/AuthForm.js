import {
  Form,
  Link,
  useSearchParams,
  useActionData,
  useNavigation,
} from 'react-router-dom';


function AuthForm() {
  const navigation = useNavigation();

  const [searchParams] = useSearchParams();
  const isLogin = searchParams.get('mode') === 'login';
  const isSubmitting = navigation.state === 'submitting';

  return (
    <>
      <Form method="post" >
        <h1>{isLogin ? 'Log in' : 'Create a new user'}</h1>
        <p>
          <label htmlFor="email">email</label>
          <input id="email" type="email" name="email" required />
        </p>
        <p>
          <label htmlFor="pwd">pwd</label>
          <input id="pwd" type="password" name="pwd" required />
        </p>
        {isLogin ? null: <p>
          <label htmlFor="name">name</label>
          <input id="name" type="text" name="name" required />
        </p>}
        
        
        <div>
          <Link to={`?mode=${isLogin ? 'signup' : 'login'}`}>
            {isLogin ? 'Create new user' : 'Login'}
          </Link>
          <button disabled={isSubmitting}>
            {isSubmitting ? 'Submitting...' : 'Save'}
          </button>
        </div>
      </Form>
    </>
  );
}

export default AuthForm;
