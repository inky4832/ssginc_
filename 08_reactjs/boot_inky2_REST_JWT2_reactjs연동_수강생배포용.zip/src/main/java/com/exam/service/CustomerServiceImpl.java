package com.exam.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exam.dto.Customer;
import com.exam.jwt.JwtUtil;
import com.exam.repository.CustomerRepository;

@Service
public class CustomerServiceImpl implements CustomerService{

	@Autowired
	private JwtUtil jwtUtil;
	
	@Autowired
	CustomerRepository resposity;
	
	
	@Override
	public Customer insertCustomer(Customer customer) throws Exception {
		int n  =resposity.insertCustomer(customer);
		return customer;
	}
	
	@Override
	public Customer login(Customer customer) throws Exception {	
		Customer c = resposity.login(customer);
		
		if(c != null) {
			//인증 성공시 authToken 생성
			String authToken = jwtUtil.createAuthToken(c.getEmail());
			c.setAuthToken(authToken);
			return c;
		}else {
			throw new RuntimeException("인증 실패");
		}
	}//

	@Override
	public Customer deleteCustomer(String email) throws Exception {
		Customer c = selectCustomerByEmail(email);
		if ( c!= null) {
			resposity.deleteCustomer(email);
		}
		return  c;
	}

	@Override
	public Customer selectCustomerByEmail(String email) throws Exception {
		return resposity.selectCustomerByEmail(email);
	}
	

	
}
