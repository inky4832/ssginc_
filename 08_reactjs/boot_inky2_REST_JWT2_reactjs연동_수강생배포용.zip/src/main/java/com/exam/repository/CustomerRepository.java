package com.exam.repository;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.exam.dto.Customer;

@Mapper
public interface CustomerRepository {

	public int insertCustomer(Customer customer) throws Exception;
	public Customer login(Customer customer) throws Exception;
	public int deleteCustomer(String email) throws Exception;
	
	public Customer selectCustomerByEmail(String email) throws Exception;

}
