DROP TABLE IF EXISTS MSA_CUSTOMER;

CREATE TABLE MSA_CUSTOMER
(
  EMAIL     VARCHAR(50) not null,
  PWD        VARCHAR(10),
  NAME      VARCHAR(20)
);

alter table MSA_CUSTOMER
  add primary key (EMAIL);
  
  
