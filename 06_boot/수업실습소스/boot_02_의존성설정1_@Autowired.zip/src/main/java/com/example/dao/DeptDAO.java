package com.example.dao;

import org.springframework.stereotype.Repository;

@Repository
public class DeptDAO {

	public DeptDAO() {
		System.out.println("DeptDAO");
	}
	
	public String getMesg() {
		return "Hello world";
	}

	
}
